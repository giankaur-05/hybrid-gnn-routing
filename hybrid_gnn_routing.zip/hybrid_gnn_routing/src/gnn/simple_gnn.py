# src/gnn/simple_gnn.py
import torch
import torch.nn as nn
import torch.nn.functional as F

class SimpleGNN(nn.Module):
    """
    A simple GNN used in the project. This class provides a small compatibility
    layer-name mapping when loading older/newer checkpoints.
    """
    def __init__(self, in_feats=6, hidden=64, out_feats=1):
        super().__init__()
        # Use the new-style names lin_in / lin_msg / lin_out (used in some checkpoints)
        self.lin_in = nn.Linear(in_feats, hidden)
        self.lin_msg = nn.Linear(hidden, hidden)
        self.lin_out = nn.Linear(hidden, out_feats)

        # Also keep aliases for older names to ease direct attribute access if code expects them
        # (these are references to the same modules)
        self.lin1 = self.lin_in
        self.lin2 = self.lin_msg
        self.out = self.lin_out

    def forward(self, feats, adj, deg):
        """
        feats: [N, F]
        adj: adjacency matrix or similar tensor (expected shape [N,N])
        deg: node degree vector (unused in this simple model but kept for compatibility)
        """
        # Basic message-passing style: linear -> relu -> aggregate by summing neighbors (adj @ h)
        h = F.relu(self.lin_in(feats))
        # message: gather neighbor features via adj multiplication
        msg = torch.matmul(adj, h)
        h = F.relu(self.lin_msg(msg))
        out = self.lin_out(h)
        return out

    def load_compat_state(self, state_dict):
        """
        Load a state_dict that may use alternative names (lin1/lin2/out)
        by mapping them to current names (lin_in, lin_msg, lin_out).
        """
        mapped = {}
        for k, v in state_dict.items():
            # direct pass-through
            if k.startswith("lin_in") or k.startswith("lin_msg") or k.startswith("lin_out"):
                mapped[k] = v
                continue
            # old naming pattern mapping: lin1 -> lin_in, lin2 -> lin_msg, out -> lin_out
            if k.startswith("lin1."):
                mapped["lin_in" + k[4:]] = v
                continue
            if k.startswith("lin2."):
                mapped["lin_msg" + k[4:]] = v
                continue
            if k.startswith("out."):
                mapped["lin_out" + k[3:]] = v
                continue
            # new style names already handled, other keys keep as-is
            mapped[k] = v

        # Now load mapped into model (allow missing/unexpected keys)
        self.load_state_dict(mapped, strict=False)

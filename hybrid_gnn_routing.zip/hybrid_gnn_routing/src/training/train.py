# src/training/train.py
import os
import torch
import torch.optim as optim
from tqdm import tqdm
import json

from src.gnn.simple_gnn import SimpleGNN
from src.utils.graph_build import graph_to_tensors
from src.utils.features import build_node_features
from src.training.dataset import get_training_sample

def train_model(epochs=30, n_graphs=200, size=20, p_noise=0.1, model_out="artifacts/gnn.pt", log_out="artifacts/train_log.json"):
    os.makedirs("artifacts", exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = SimpleGNN().to(device)
    opt = optim.Adam(model.parameters(), lr=1e-3, weight_decay=1e-5)
    loss_fn = torch.nn.L1Loss()

    history = {"loss": []}

    for ep in range(epochs):
        total_loss = 0.0
        pbar = tqdm(range(n_graphs), desc=f"Epoch {ep+1}/{epochs}", ncols=80)
        for _ in pbar:
            G, goal, y = get_training_sample(size=size, p_noise=p_noise)
            adj, deg, coords = graph_to_tensors(G)   # numpy -> torch
            # move to device
            adj = adj.to(device)
            deg = deg.to(device)
            coords = coords.to(device)

            feats = build_node_features(coords, goal).to(device)
            y_t = torch.tensor(y, device=device)

            pred = model(feats, adj, deg)

            loss = loss_fn(pred, y_t)
            opt.zero_grad()
            loss.backward()
            opt.step()

            total_loss += loss.item()
            pbar.set_postfix({"loss": f"{loss.item():.4f}"})

        avg = total_loss / n_graphs
        history["loss"].append(avg)
        print(f"Epoch {ep+1}: Loss {avg:.6f}")

        # checkpoint every 5 epochs
        if (ep + 1) % 5 == 0:
            torch.save(model.state_dict(), model_out.replace(".pt", f".ep{ep+1}.pt"))
            print("Saved checkpoint:", model_out.replace(".pt", f".ep{ep+1}.pt"))

    # final save
    torch.save(model.state_dict(), model_out)
    with open(log_out, "w") as f:
        json.dump(history, f)
    print("Model saved to", model_out)
    print("Training log saved to", log_out)

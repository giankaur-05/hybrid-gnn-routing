# src/training/dataset.py
"""
Dataset helpers for training.
Uses a relative import so it works whether `src` is a package or you're running
from project root.
"""

from typing import Tuple
import random
import networkx as nx

# Relative import (works from inside package)
try:
    # when running as a package (recommended)
    from ..utils.make_synthetic_graphs import make_grid_graph
except Exception:
    # fallback to absolute import if package not detected
    from src.utils.make_synthetic_graphs import make_grid_graph


def get_training_sample(size: int = 20, p_noise: float = 0.02, seed: int = None) -> Tuple[nx.Graph, int, int]:
    """
    Returns (G, start_node, goal_node).
    Uses make_grid_graph(...) from utils. The grid generator must return:
      G (networkx.Graph), start_node (int), goal_node (int)
    If your make_grid_graph returns a different shape, adapt accordingly.
    """
    if seed is not None:
        random.seed(seed)

    # make_grid_graph should accept size and p_noise (match your implementation)
    result = make_grid_graph(size=size, p_noise=p_noise, seed=seed)

    # if make_grid_graph returns (G, s, t) -> use it directly
    if isinstance(result, tuple) and len(result) >= 3:
        G, s, t = result[0], result[1], result[2]
        return G, s, t

    # if it returns just a Graph, pick random start/goal
    if isinstance(result, nx.Graph):
        G = result
        nodes = list(G.nodes())
        if len(nodes) < 2:
            raise ValueError("Generated graph has fewer than 2 nodes.")
        s, t = random.sample(nodes, 2)
        return G, s, t

    raise RuntimeError("Unexpected return from make_grid_graph() — expected (G,s,t) or G.")

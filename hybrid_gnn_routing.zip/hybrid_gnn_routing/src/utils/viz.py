# src/utils/viz.py
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np

def draw_and_save(G, s, t, path, outpath):
    """
    Draw grid with path (path is a list of node indices). Saves PNG.
    """
    plt.figure(figsize=(4,4))
    ax = plt.gca()
    size = int(np.sqrt(len(G)))
    # draw grid: use node coords
    pos = {n:(G.nodes[n]['y'], -G.nodes[n]['x']) for n in G.nodes()}  # y horizontal, x vertical
    nx.draw(G, pos=pos, node_size=40, node_color="white", edge_color="#ccc", with_labels=False, ax=ax)
    if path:
        path_edges = list(zip(path[:-1], path[1:]))
        nx.draw_networkx_nodes(G, pos=pos, nodelist=path, node_color='red', node_size=60, ax=ax)
        nx.draw_networkx_edges(G, pos=pos, edgelist=path_edges, edge_color='red', width=2, ax=ax)
    ax.set_axis_off()
    plt.tight_layout()
    plt.savefig(outpath, dpi=150)
    plt.close()

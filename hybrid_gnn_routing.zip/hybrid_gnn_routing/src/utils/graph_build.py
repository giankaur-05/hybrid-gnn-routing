import torch
import numpy as np


def graph_to_tensors(G):
    n = G.number_of_nodes()

    # adjacency (weighted inverse)
    adj = np.zeros((n, n), dtype=np.float32)
    for u, v, d in G.edges(data=True):
        w = d["weight"]
        adj[u, v] = 1.0 / w
        adj[v, u] = 1.0 / w

    # degree
    deg = np.sum(adj > 0, axis=1).astype(np.float32)

    # coords
    xs = np.array([G.nodes[u]["x"] for u in G.nodes()])
    ys = np.array([G.nodes[u]["y"] for u in G.nodes()])
    coords = np.stack([xs, ys], axis=1).astype(np.float32)

    return (
        torch.tensor(adj),
        torch.tensor(deg),
        torch.tensor(coords),
    )

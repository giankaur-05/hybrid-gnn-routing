# data/make_synthetic_graphs.py
import networkx as nx
import random

def make_grid_graph(size, seed=None, p_noise: float = 0.0):
    """
    Build a square grid graph with `size x size` nodes, optional random edge removal (p_noise).
    Returns (G, s, t) where G is a networkx.Graph, s and t are start/goal node indices.

    - size: int, node grid side length
    - seed: optional int seed for reproducibility
    - p_noise: float in [0,1], probability to remove each edge (simulates obstacles/noise)
    """
    if seed is not None:
        random.seed(seed)

    G = nx.Graph()
    # Create nodes with x,y attributes for plotting
    for i in range(size):
        for j in range(size):
            node_id = i * size + j
            # coordinates: x=j, y=(size-1-i) so origin becomes bottom-left in plots
            G.add_node(node_id, x=j, y=(size - 1 - i))

    # Add 4-neighbor grid edges
    for i in range(size):
        for j in range(size):
            u = i * size + j
            if j + 1 < size:
                v = i * size + (j + 1)
                G.add_edge(u, v, weight=1.0)
            if i + 1 < size:
                v = (i + 1) * size + j
                G.add_edge(u, v, weight=1.0)

    # Optionally remove edges randomly according to p_noise
    if p_noise and p_noise > 0.0:
        edges = list(G.edges())
        for (u, v) in edges:
            if random.random() < float(p_noise):
                if G.has_edge(u, v):
                    G.remove_edge(u, v)

    # Pick random distinct start and target
    all_nodes = list(G.nodes())
    if not all_nodes:
        raise RuntimeError("Grid size produced 0 nodes")

    s = random.choice(all_nodes)
    t = random.choice(all_nodes)
    while t == s:
        t = random.choice(all_nodes)

    return G, s, t

# src/utils/features.py
import numpy as np

def build_node_features(G, goal):
    """
    Returns numpy array shape (N, 6):
    [x, y, gx, gy, dx, dy]
    where (x,y) are node coords, (gx,gy) are goal coords, (dx,dy)=goal - node coords
    Node ordering is sorted(G.nodes())
    """
    nodes = sorted(G.nodes())
    gx = G.nodes[goal]['x']
    gy = G.nodes[goal]['y']
    feats = []
    for n in nodes:
        x = G.nodes[n]['x']
        y = G.nodes[n]['y']
        dx = gx - x
        dy = gy - y
        feats.append([x, y, gx, gy, dx, dy])
    return np.array(feats, dtype=float)

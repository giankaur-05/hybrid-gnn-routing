# src/algorithms/dijkstra_astar.py
import heapq
import math
import networkx as nx

def dijkstra_path(G, s, t):
    # returns (path_list, cost)
    path = nx.dijkstra_path(G, s, t, weight='weight')
    cost = nx.dijkstra_path_length(G, s, t, weight='weight')
    return path, float(cost)

def euclid_heuristic(G, u, goal):
    x1 = G.nodes[u]['x']; y1 = G.nodes[u]['y']
    x2 = G.nodes[goal]['x']; y2 = G.nodes[goal]['y']
    return math.hypot(x2 - x1, y2 - y1)

def astar_custom(G, s, t, h_func=None):
    """
    h_func(u) -> heuristic (float). if None use euclid.
    returns (path, cost)
    """
    if h_func is None:
        h_func = lambda u: euclid_heuristic(G, u, t)

    open_heap = []
    heapq.heappush(open_heap, (h_func(s), 0.0, s, None))  # (f, g, node, parent)
    parents = {}
    gscore = {s: 0.0}
    closed = set()

    while open_heap:
        f, g, n, parent = heapq.heappop(open_heap)
        if n in closed:
            continue
        parents[n] = parent
        if n == t:
            # reconstruct path
            path = []
            cur = t
            while cur is not None:
                path.append(cur)
                cur = parents.get(cur, None)
            path.reverse()
            return path, float(g)
        closed.add(n)
        for nb in G.neighbors(n):
            w = G.edges[n, nb].get('weight', 1.0)
            tentative = g + w
            if tentative < gscore.get(nb, float('inf')):
                gscore[nb] = tentative
                fnb = tentative + h_func(nb)
                heapq.heappush(open_heap, (fnb, tentative, nb, n))
    return None, float('inf')

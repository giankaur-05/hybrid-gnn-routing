import torch


class GNNHeuristic:
    def __init__(self, model, adj, deg, feats):
        self.model = model
        self.adj = adj
        self.deg = deg
        self.feats = feats

    def __call__(self, G, u, goal):
        with torch.no_grad():
            pred = self.model(self.feats, self.adj, self.deg)
        return float(pred[u].item())

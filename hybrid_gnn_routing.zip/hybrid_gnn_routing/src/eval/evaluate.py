# src/eval/evaluate.py
"""
Robust evaluator for hybrid GNN routing project.

This file tolerates different function names across forks:
- dijkstra function names: dijkstra_path, dijkstra
- astar function names: astar_path, astar, astar_custom
- viz function names: draw_paths, draw_and_save, draw_path

It also tolerates model files that are either:
- a saved state_dict (dict of tensors), or
- a saved model object (callable / nn.Module).
"""

import os
import time
import json
import csv
import random
import traceback

import torch
import numpy as np
import networkx as nx

# imports we expect to exist in your project; we will fallback if names differ
try:
    from src.gnn.simple_gnn import SimpleGNN
except Exception:
    # fallback: try importing from gnn.simple_gnn if src not package-resolved
    from gnn.simple_gnn import SimpleGNN  # type: ignore

# Try multiple possible locations/names for algorithms and viz helpers.
# --- Algorithms ---
_dijkstra_fn = None
_astar_fn = None
try:
    import src.algorithms.dijkstra_astar as alg_mod
except Exception:
    try:
        import algorithms.dijkstra_astar as alg_mod  # fallback
    except Exception:
        alg_mod = None

if alg_mod is not None:
    # dijkstra
    for name in ("dijkstra_path", "dijkstra", "dijkstra_search"):
        if hasattr(alg_mod, name):
            _dijkstra_fn = getattr(alg_mod, name)
            break
    # astar
    for name in ("astar_path", "astar", "astar_custom", "astar_search"):
        if hasattr(alg_mod, name):
            _astar_fn = getattr(alg_mod, name)
            break

# If missing, define simple wrappers that raise helpful error when called.
def _missing_dijkstra(*args, **kwargs):
    raise RuntimeError("Dijkstra function not found in src.algorithms.dijkstra_astar. "
                       "Look for dijkstra_path/dijkstra in that module.")
def _missing_astar(*args, **kwargs):
    raise RuntimeError("A* function not found in src.algorithms.dijkstra_astar. "
                       "Look for astar_path/astar_custom in that module.")

dijkstra_path = _dijkstra_fn if _dijkstra_fn is not None else _missing_dijkstra
astar_fn = _astar_fn if _astar_fn is not None else _missing_astar

# --- Viz helpers: try several names ---
_draw_helper = None
try:
    import src.utils.viz as viz_mod
except Exception:
    try:
        import utils.viz as viz_mod
    except Exception:
        viz_mod = None

if viz_mod is not None:
    for name in ("draw_paths", "draw_and_save", "draw_path", "draw"):
        if hasattr(viz_mod, name):
            _draw_helper = getattr(viz_mod, name)
            break

# --- Graph generator and features ---
# prefer src.utils.make_synthetic_graphs, fall back to data or utils locations
make_grid_graph = None
try:
    from src.utils.make_synthetic_graphs import make_grid_graph as _mg
    make_grid_graph = _mg
except Exception:
    try:
        from src.utils.make_synthetic_graphs import make_grid_graph as _mg
        make_grid_graph = _mg
    except Exception:
        try:
            from data.make_synthetic_graphs import make_grid_graph as _mg
            make_grid_graph = _mg
        except Exception:
            make_grid_graph = None

# features builder
try:
    from src.utils.features import build_node_features
except Exception:
    try:
        from utils.features import build_node_features
    except Exception:
        build_node_features = None


def _safe_call_astar(G, s, t, heuristic=None):
    """
    Call the repo's A* function with best-effort mapping of arguments.
    Returns (path, cost).
    """
    if astar_fn is _missing_astar:
        return None, float("inf")
    try:
        # try common signatures
        # 1) astar(G, start, goal, heuristic=None)
        try:
            return astar_fn(G, s, t, heuristic)
        except TypeError:
            pass
        # 2) astar_path(G, start, goal)
        try:
            return astar_fn(G, s, t)
        except TypeError:
            pass
        # 3) astar_custom(G, s, t, heuristic=None) with heuristic that takes node->value
        return astar_fn(G, s, t, heuristic)
    except Exception:
        # return fallback
        traceback.print_exc()
        return None, float("inf")


def _safe_call_dijkstra(G, s, t):
    if dijkstra_path is _missing_dijkstra:
        return None, float("inf")
    try:
        return dijkstra_path(G, s, t)
    except TypeError:
        # maybe different signature
        try:
            return dijkstra_path(G, s, t)
        except Exception:
            traceback.print_exc()
            return None, float("inf")
    except Exception:
        traceback.print_exc()
        return None, float("inf")


def _load_model_tolerant(model_cls, model_path, device):
    """
    Accepts either:
    - a saved nn.Module (torch.save(model)) -> torch.load returns module
    - a saved state_dict (torch.save(model.state_dict())) -> torch.load returns dict
    Returns a model instance (nn.Module) on device.
    """
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"Model file not found: {model_path}")

    loaded = torch.load(model_path, map_location=device)

    # Case A: user saved entire model object (loaded is nn.Module)
    if isinstance(loaded, torch.nn.Module):
        model = loaded
        return model.to(device)

    # Case B: user saved checkpoint dict containing 'model' or 'state_dict'
    if isinstance(loaded, dict):
        # if it contains a nested model/state_dict, extract it
        possible = None
        for key in ("model_state", "state_dict", "model", "net"):
            if key in loaded and isinstance(loaded[key], dict):
                possible = loaded[key]
                break
        if possible is not None:
            state_dict = possible
        else:
            # loaded may itself be the state_dict
            state_dict = loaded

        # instantiate fresh model and load
        model = model_cls()
        # try to remap old/new names heuristically
        keys = list(state_dict.keys())
        # if keys look like they are prefixed with 'module.' (DataParallel), strip it
        if any(k.startswith("module.") for k in keys):
            new_sd = {k.replace("module.", ""): v for k, v in state_dict.items()}
            state_dict = new_sd

        # try heuristic mapping for old checkpoints that used different layer names
        # e.g. lin1 -> lin_in, lin2 -> lin_msg, out -> lin_out
        remapped = {}
        if any(k.startswith("lin1.") or k.startswith("lin2.") or k.startswith("out.") for k in keys):
            for k, v in state_dict.items():
                new_k = k
                if k.startswith("lin1."):
                    new_k = "lin_in." + k.split(".", 1)[1]
                elif k.startswith("lin2."):
                    new_k = "lin_msg." + k.split(".", 1)[1]
                elif k.startswith("out."):
                    new_k = "lin_out." + k.split(".", 1)[1]
                remapped[new_k] = v
            state_dict = remapped

        # final load with strict=False to be tolerant
        try:
            model.load_state_dict(state_dict, strict=False)
        except Exception:
            try:
                # sometimes the state_dict is nested inside a value (e.g. {'model': state_dict})
                if isinstance(state_dict, dict) and any(isinstance(v, dict) for v in state_dict.values()):
                    # pick largest dict value
                    cand = None
                    for v in state_dict.values():
                        if isinstance(v, dict):
                            if cand is None or len(v) > len(cand):
                                cand = v
                    if cand is not None:
                        model.load_state_dict(cand, strict=False)
            except Exception:
                traceback.print_exc()
        return model.to(device)

    # Unknown type — attempt to construct model and hope for the best
    model = model_cls()
    try:
        model.load_state_dict(loaded, strict=False)
    except Exception:
        # final fallback: create uninitialized model
        pass
    return model.to(device)


def evaluate_model(queries=200, size=20, save_folder="artifacts",
                   model_path="artifacts/gnn.pt", seed=None):
    """
    Runs evaluation and writes:
      - artifacts/eval_results.csv
      - artifacts/summary.json
      - optional example images (if viz helper present)
    """
    if seed is not None:
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)

    if make_grid_graph is None:
        raise RuntimeError("make_grid_graph not found. Place make_synthetic_graphs.py in src/utils or data.")

    if build_node_features is None:
        raise RuntimeError("build_node_features not found in src.utils.features")

    os.makedirs(save_folder, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # instantiate & load model (tolerant)
    model = _load_model_tolerant(SimpleGNN, model_path, device)
    model.eval()

    results = []
    d_times = []
    a_times = []
    h_times = []
    d_costs = []
    a_costs = []
    h_costs = []

    for qi in range(queries):
        print(f"Query {qi+1}/{queries}")

        # Build graph and query
        # many make_grid_graph implementations return (G,s,t) — pass seed+size+p_noise if present
        try:
            maybe = make_grid_graph(size=size, seed=qi)
        except TypeError:
            # fallback if signature different
            maybe = make_grid_graph(size, qi)

        if isinstance(maybe, (tuple, list)) and len(maybe) >= 3:
            G, s, t = maybe[0], maybe[1], maybe[2]
        elif isinstance(maybe, nx.Graph):
            G = maybe
            nodes = list(G.nodes())
            if len(nodes) < 2:
                raise RuntimeError("Generated graph too small")
            s, t = random.sample(nodes, 2)
        else:
            raise RuntimeError("make_grid_graph returned unexpected type")

        # build features & adjacency
        feats_np = build_node_features(G, goal=t)  # repo's feature builder
        adj = nx.to_numpy_array(G, nodelist=sorted(G.nodes())).astype(np.float32)
        deg = np.array([G.degree(n) for n in sorted(G.nodes())], dtype=np.float32)

        feats = torch.tensor(feats_np, dtype=torch.float32).to(device)
        adj_t = torch.tensor(adj, dtype=torch.float32).to(device)
        deg_t = torch.tensor(deg, dtype=torch.float32).to(device)

        # DIJKSTRA
        t0 = time.time()
        try:
            p_d, cost_d = _safe_call_dijkstra(G, s, t)
        except Exception:
            p_d, cost_d = None, float("inf")
        t1 = time.time()
        dt = (t1 - t0) * 1000.0

        # ASTAR (baseline)
        t0 = time.time()
        try:
            p_a, cost_a = _safe_call_astar(G, s, t, heuristic=None)
        except Exception:
            p_a, cost_a = None, float("inf")
        t1 = time.time()
        at = (t1 - t0) * 1000.0

        # GNN-driven / hybrid: get model predictions and use as heuristic if your astar supports it
        t0 = time.time()
        with torch.no_grad():
            try:
                pred = model(feats, adj_t, deg_t)
                # normalize / squeeze to 1D numeric array
                try:
                    h_vals = pred.squeeze().cpu().numpy()
                except Exception:
                    h_vals = np.array(pred).squeeze()
            except Exception:
                # if model object was saved directly and is callable differently
                try:
                    pred = model(feats)
                    h_vals = pred.squeeze().cpu().numpy()
                except Exception:
                    h_vals = None
        # call astar with heuristic if supported; our _safe_call_astar attempts to pass heuristic
        try:
            p_h, cost_h = _safe_call_astar(G, s, t, heuristic=(lambda u: float(h_vals[u]) if h_vals is not None else 0.0))
        except Exception:
            p_h, cost_h = None, float("inf")
        t1 = time.time()
        ht = (t1 - t0) * 1000.0

        # record
        results.append({
            "query": qi,
            "dijkstra_time_ms": dt,
            "astar_time_ms": at,
            "hybrid_time_ms": ht,
            "dijkstra_cost": float(cost_d) if np.isfinite(cost_d) else None,
            "astar_cost": float(cost_a) if np.isfinite(cost_a) else None,
            "hybrid_cost": float(cost_h) if np.isfinite(cost_h) else None
        })
        d_times.append(dt); a_times.append(at); h_times.append(ht)
        d_costs.append(float(cost_d) if np.isfinite(cost_d) else np.nan)
        a_costs.append(float(cost_a) if np.isfinite(cost_a) else np.nan)
        h_costs.append(float(cost_h) if np.isfinite(cost_h) else np.nan)

        # Save example images for first few queries if viz helper exists
        if qi < 3 and _draw_helper is not None:
            try:
                # try common signatures for draw helper
                # draw_paths(G, s, t, path, save_to=...)
                save_to_d = os.path.join(save_folder, f"example_query_{qi}_dijkstra.png")
                try:
                    _draw_helper(G, s, t, p_d, save_to=save_to_d)
                except TypeError:
                    # try positional
                    _draw_helper(G, s, t, p_d, save_to_d)
            except Exception as e:
                print("[WARN] saving viz failed:", e)

    # Write CSV
    csv_path = os.path.join(save_folder, "eval_results.csv")
    keys = list(results[0].keys()) if results else ["query"]
    with open(csv_path, "w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=keys)
        writer.writeheader()
        writer.writerows(results)

    # Summary
    def safe_mean(lst):
        try:
            return float(np.nanmean(np.array(lst)))
        except Exception:
            return None

    summary = {
        "dijkstra": {"avg_time_ms": safe_mean(d_times), "avg_cost": safe_mean(d_costs)},
        "astar": {"avg_time_ms": safe_mean(a_times), "avg_cost": safe_mean(a_costs)},
        "hybrid_gnn": {"avg_time_ms": safe_mean(h_times), "avg_cost": safe_mean(h_costs)},
    }

    json_path = os.path.join(save_folder, "summary.json")
    with open(json_path, "w") as fh:
        json.dump(summary, fh, indent=2)

    print("=== EVALUATION COMPLETE ===")
    print("Saved CSV to", csv_path)
    print("Saved summary to", json_path)
    return summary

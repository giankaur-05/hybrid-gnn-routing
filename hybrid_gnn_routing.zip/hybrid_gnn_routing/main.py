# main.py

import argparse
import os
import sys
import torch

# Fix root
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, PROJECT_ROOT)

from src.training.train import train_model
from src.eval.evaluate import evaluate_model


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="cmd")

    # ===== TRAIN =====
    train_p = sub.add_parser("train")
    train_p.add_argument("--epochs", type=int, default=50)
    train_p.add_argument("--graphs", type=int, default=500)
    train_p.add_argument("--size", type=int, default=20)
    train_p.add_argument("--p_noise", type=float, default=0.02)

    # ===== EVAL =====
    eval_p = sub.add_parser("eval")
    eval_p.add_argument("--queries", type=int, default=200)
    eval_p.add_argument("--size", type=int, default=20)
    eval_p.add_argument("--model", type=str, default="artifacts/gnn.pt")
    eval_p.add_argument("--save_folder", type=str, default="artifacts")
    eval_p.add_argument("--seed", type=int, default=None)

    args = parser.parse_args()

    if args.cmd == "train":
        train_model(
            epochs=args.epochs,
            n_graphs=args.graphs,
            size=args.size,
            p_noise=args.p_noise,
        )

    elif args.cmd == "eval":
        evaluate_model(
            queries=args.queries,
            size=args.size,
            save_folder=args.save_folder,
            model_path=args.model,
            seed=args.seed
        )

    else:
        print("Specify a command: train / eval")


if __name__ == "__main__":
    main()
